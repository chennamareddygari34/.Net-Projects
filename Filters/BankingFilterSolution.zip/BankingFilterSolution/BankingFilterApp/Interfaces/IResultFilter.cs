﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace BankingWebApi.Interfaces
{
    public interface IResultFilter
    {
        void OnResultExecuting(ResultExecutingContext context);

    }
}
