﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace BankingWebApi.Interfaces
{
    public interface IActionFilter
    {
        void OnActionExecuting(ActionExecutingContext context);
        void OnActionExecuted(ActionExecutedContext context);

    }
}
