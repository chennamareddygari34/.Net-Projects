﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;

namespace BankingWebApi.Services
{
    public class ResponseLogFilter : IActionFilter
    {
        private readonly ILogger<ResponseLogFilter> _logger;

        public ResponseLogFilter(ILogger<ResponseLogFilter> logger)
        {
            _logger = logger;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            // No action needed before execution
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            _logger.LogInformation($"Response: {context.HttpContext.Response.StatusCode}");
        }
    }
}
