﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace BankingWebApi.Services
{
    public class AuthActionFilter : IActionFilter
    {
        

        public void OnActionExecuting(ActionExecutingContext context)
        {
            
            Console.WriteLine($"This Filter Executed on : OnActionExecuting");
        }
        
        public void OnActionExecuted(ActionExecutedContext context)
        {
            Console.WriteLine($"This Filter Executed on : OnActionExecuted");
        }
    }
}
