﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;

namespace BankingWebApi.Services
{
    public class BankingResultFilter : IResultFilter
    {
        private readonly ILogger<BankingResultFilter> _logger;

        public BankingResultFilter(ILogger<BankingResultFilter> logger)
        {
            _logger = logger;
        }

        public void OnResultExecuting(ResultExecutingContext context)
        {
            // No action needed before result execution
        }

        public void OnResultExecuted(ResultExecutedContext context)
        {
            // Log the result if needed
            _logger.LogInformation($"Result: {context.Result}");
        }
    }
}
