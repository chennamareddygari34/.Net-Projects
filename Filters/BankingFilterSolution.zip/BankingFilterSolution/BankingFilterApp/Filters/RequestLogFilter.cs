﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;

namespace BankingWebApi.Services
{
    public class RequestLogFilter : IActionFilter
    {
        private readonly ILogger<RequestLogFilter> _logger;

        public RequestLogFilter(ILogger<RequestLogFilter> logger)
        {
            _logger = logger;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            _logger.LogInformation($"Request: {context.HttpContext.Request.Path} {context.HttpContext.Request.Method}");
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            // No action needed after execution
        }
    }
}
