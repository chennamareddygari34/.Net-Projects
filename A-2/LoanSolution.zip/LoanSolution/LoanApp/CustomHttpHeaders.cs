﻿namespace LoanApp
{
    public class CustomHttpHeaders
    {
        public const string ApiVersion = "Api-Version";
    }
}
