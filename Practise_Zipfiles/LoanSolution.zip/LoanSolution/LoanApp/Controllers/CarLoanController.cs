﻿using LoanApp.Interfaces;
using LoanApp.Models;
using LoanApp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LoanApp.Controllers
{
    [ApiController]
    [ApiVersion("2.0")]
    //[Route("api/v{version:apiVersion}/loan")]
    [Route("api/v2/loan")]
    public class CarLoanController : ControllerBase
    {
        private readonly ICarLoanService _carloanService;
        public CarLoanController(ICarLoanService carloanService)
        {
            _carloanService = carloanService;
        }

        //[HttpGet]
        //public IActionResult Get()
        //{
        //    return Ok("This is the GET method for CarLoanController v1.0");
        //}
        [HttpPost]
        public IActionResult GetLoanDetails(CarLoanRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var loanDetails = _carloanService.GetCarLoanDetails(request);
            return Ok(loanDetails);

            //var loanAmount = (int)(request.CarPrice * 0.8);
            //var interestRate = 8;
            //var tenure = 5;

            //var response = new CarLoanResponse
            //{
            //    ApplicableLoanAmount = loanAmount,
            //    InterestRate = interestRate,
            //    TenureInYears = tenure
            //};

            //return Ok(response);
        }
    }
}

