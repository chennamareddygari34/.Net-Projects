﻿using LoanApp.Interfaces;
using LoanApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LoanApp.Controllers
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/loan")]
    //[Route("api/v1/loan")]
    public class BikeLoanController : ControllerBase
    {
        private readonly IBikeLoanService _bikeloanService;
        public BikeLoanController(IBikeLoanService bikeloanService)
        {
            _bikeloanService = bikeloanService;
        }

        //[HttpGet]
        //public IActionResult Get()
        //{
        //    return Ok("This is the GET method for BikeLoanController v1.0");
        //}
        [HttpPost]
        public IActionResult GetBikeLoanDetails(BikeLoanRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var loanDetails =  _bikeloanService.GetBikeLoanDetails(request);
            return Ok(loanDetails);

            //var loanAmount = (int)(request.BikePrice * 0.2);
            //var interestRate = 8;
            //var tenure = 2;

            //var response = new BikeLoanResponse
            //{
            //    ApplicableLoanAmount = loanAmount,
            //    InterestRate = interestRate,
            //    TenureInYears = tenure
            //};

            //return Ok(response);
        }
    }
}

