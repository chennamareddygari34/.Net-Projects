﻿using System.ComponentModel.DataAnnotations;

namespace BankAcountEstatementApp.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string UserName { get; set; }
        public byte[] Password { get; set; }
    }
}
