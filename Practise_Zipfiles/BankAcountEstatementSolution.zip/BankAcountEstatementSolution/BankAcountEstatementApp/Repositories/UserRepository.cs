﻿using BankAcountEstatementApp.Contexts;
using BankAcountEstatementApp.Interfaces;
using BankAcountEstatementApp.Models;

namespace BankAcountEstatementApp.Repositories
{
    public class UserRepository : IRepository<string, User>
    {
        private readonly UserContext _context;
        public UserRepository(UserContext context)
        {
            _context = context;
        }

        public User AddNewUser(User item)
        {
            throw new NotImplementedException();
        }

        

        public User Delete(string key)
        {
            throw new NotImplementedException();
        }

        public User Get(string key)
        {
            throw new NotImplementedException();
        }

        public List<User> GetAll()
        {
            throw new NotImplementedException();
        }

        public User Update(User item)
        {
            throw new NotImplementedException();
        }
    }

    public interface IRepository<T1, T2>
    {
    }
}
