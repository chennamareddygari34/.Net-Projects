﻿using BankAcountEstatementApp.Interfaces;
using BankAcountEstatementApp.Models;
using BankAcountEstatementApp.Repositories;

namespace BankAcountEstatementApp.Services
{
    public class UserService : IUserService
    {

        private readonly List<User> _users = new List<User>
    {
        new User { Id = 1, UserName = "user1" },
        new User { Id = 2, UserName = "user2" },
        new User { Id = 3, UserName="user3"}

    };
        private readonly object _userRepository;

        public Task<User> GetUserById(int id)
        {
            var user = _users.Find(u => u.Id == id);
            return Task.FromResult(user);
        }

        public Task<List<User>> GetAllUsers()
        {
            return Task.FromResult(_users);
        }

        
    }
    
}