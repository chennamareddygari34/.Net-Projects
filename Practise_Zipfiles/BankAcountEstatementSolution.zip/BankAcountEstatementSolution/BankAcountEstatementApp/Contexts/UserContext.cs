﻿using BankAcountEstatementApp.Models;
using Microsoft.EntityFrameworkCore;

namespace BankAcountEstatementApp.Contexts
{
    public class UserContext:DbContext
    {
        public UserContext(DbContextOptions options):base(options) 
        {
            
        }
        public DbSet<User> users { get; set; }
        
    }
}
