﻿using BankAcountEstatementApp.Models;

namespace BankAcountEstatementApp.Interfaces
{
    public interface IUserService
    {

        Task<User> GetUserById(int id);
        Task<List<User>> GetAllUsers();

       
    }
}
