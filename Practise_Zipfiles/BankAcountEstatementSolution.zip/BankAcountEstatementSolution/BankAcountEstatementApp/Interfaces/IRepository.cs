﻿using BankAcountEstatementApp.Models;

namespace BankAcountEstatementApp.Interfaces
{
    public interface IRepository
    {
        Task<User> AddNewUserAsync(User user);

    }
}
