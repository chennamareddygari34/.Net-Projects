﻿using System.Transactions;

namespace BankAcountEstatementApp.Interfaces
{
    public interface ITransactionService
    {
        Transaction GetTransactions();
        Transaction GetTransactionById(int id);
        Transaction AddTransaction(Transaction transaction);
        Transaction UpdateTransaction(Transaction transaction);
        Transaction DeleteTransaction(int id);
    }
}
