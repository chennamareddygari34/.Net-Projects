﻿using System.Globalization;
using BankAcountEstatementApp.Interfaces;
using BankAcountEstatementApp.Models;
using BankAcountEstatementApp.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace BankAcountEstatementApp.Services
{
    public class CurrencyService : ICurrencyService
    {

        private readonly IServiceScopeFactory _serviceScopeFactory;

        public CurrencyService(IServiceScopeFactory serviceScopeFactory) { _serviceScopeFactory = serviceScopeFactory; }
        public void Execute()
        {
            using (var scope = _serviceScopeFactory.CreateScope())
            {
                var myScopedService = scope.ServiceProvider.GetService<IRepository>();

                myScopedService.DoSomething();
            }
        }
    }
}
        

//private readonly IRepository<int, Currency> _repository;

//public CurrencyService(IRepository<int, Currency> repository)
//{
//    _repository = repository;
//}

// public List<Currency> GetAllCurrency()
// {
//     //return _repository.GetAll();
//     return null;

// }


//public Currency CreateCurrency(Currency currency)
// {
//     //return _repository.Add(currency);
//     return null;
// }