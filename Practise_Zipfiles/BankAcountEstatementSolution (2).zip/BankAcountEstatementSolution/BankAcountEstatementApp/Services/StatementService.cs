﻿using BankAcountEstatementApp.Interfaces;
using BankAcountEstatementApp.Models;

using BankAcountEstatementApp.Utilities;


namespace BankAcountEstatementApp.Services
{
    public class StatementService : IStatementService

    {
        private readonly IRepository<int, Statement> _repository;
        private readonly object _context;
        private Account? accountNumber;
        private readonly ICurrencyService _currencyService;

        public StatementService(IRepository<int, Statement> repository, ICurrencyService currencyService)
        {
            _repository = repository;
            _currencyService = currencyService;
        }

        public Statement CreateStatement(Statement Statement)
        {
            return _repository.Add(Statement);
        }

    

        public List<Statement> GetStatementsForAccount(int accountNumber)
        {

            var list = GetStatement();
            var reslist = list.Where(pro => pro.AccountNumber == accountNumber).ToList();
            if (reslist.Count() > 0)
            {
                return reslist;
            }
            else
            {
                throw new InvalidUserEntry();
            }
        }

       public List<Statement> GetStatement()
        {
            return _repository.GetAll();


        }
        //public decimal ConvertAmount(decimal amount, string sourceCurrency, string targetCurrency)
        //{
        //    return _currencyService.ConvertCurrency(amount, sourceCurrency, targetCurrency);
        //}

        //public string FormatAmount(decimal amount, string currencyCode)
        //{
            
        //    return _currencyService.FormatCurrency(amount, currencyCode);
        //}


    }
}


