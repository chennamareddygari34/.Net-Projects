﻿using BankAcountEstatementApp.Models;

namespace BankAcountEstatementApp.Interfaces
{
    public interface ICurrencyService
    {
        //List<Currency> GetAllCurrency();
        //Currency CreateCurrency(Currency currency);
        //decimal ConvertCurrency(decimal amount, string sourceCurrency, string targetCurrency);
        //string FormatCurrency(decimal amount, string currencyCode);

    }
}
