﻿using System.Security.Principal;
using BankAcountEstatementApp.Interfaces;
using BankAcountEstatementApp.Models;
using BankAcountEstatementApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace BankAcountEstatementApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StatementController : ControllerBase
    {
        private readonly IStatementService _statementService;
        private readonly IAccountService _accountService;

        public StatementController(IStatementService statementService)
        {
            _statementService = statementService;
            
        }
        [HttpGet]
        public IActionResult GetStatement()
        {
            var statements = _statementService.GetStatement();
            return Ok(statements);
        }
        [HttpPost]
        public ActionResult CreateStatement (Statement statement)
        {
            var createdStatement = _statementService.CreateStatement(statement);
            return Ok();

        }


        [HttpGet("statements/{accountNumber}")]
        public ActionResult<List<Statement>> GetStatementsForAccount(int accountNumber)
        {
            var statements = _statementService.GetStatementsForAccount(accountNumber);
            
            if (statements == null)
            {
                return NotFound();
            }

            return statements;
        }





    }

}



